# StorySaver (React + Vite)

Aplikasi front-end untuk menyimpan salinan foto/video yang sudah dimiliki pengguna atau dibagikan dengan izin. File dipilih dan disimpan secara lokal di browser.

## Menjalankan di komputer

1. Install Node.js versi LTS.
2. Ekstrak folder project.
3. Buka terminal di folder project.
4. Jalankan:

   ```bash
   npm install
   npm run dev
   ```

5. Buka alamat lokal yang ditampilkan Vite (biasanya http://localhost:5173).

## Batasan penting

- Kolom tautan hanya menyimpan tautan sebagai catatan dan tombol membuka Instagram.
- Aplikasi ini **tidak** mengambil media langsung dari tautan Instagram, tidak melewati akun private, dan tidak meminta password/cookie/session.
- Untuk menyimpan Story, minta pemilik mengirim file atau gunakan fitur unduh resmi Instagram bila tersedia. Setelah itu pilih file di aplikasi lalu tekan **Simpan ke perangkat**.
- File tidak diunggah ke server; pemrosesan berlangsung di browser.
